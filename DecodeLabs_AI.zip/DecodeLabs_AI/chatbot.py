# ============================================
# DecodeLabs AI Internship - Project 1
# Rule-Based AI Chatbot - PRO VERSION 🚀
# ============================================

# COLORS for terminal
class Colors:
    CYAN    = '\033[96m'
    GREEN   = '\033[92m'
    YELLOW  = '\033[93m'
    RED     = '\033[91m'
    BOLD    = '\033[1m'
    RESET   = '\033[0m'

# KNOWLEDGE BASE - Partial Matching ke liye keywords
knowledge_base = [
    {"keywords": ["hello", "hi", "hey", "assalam"],       "reply": "Hello! Welcome to DecoBot 🤖"},
    {"keywords": ["how are you", "kaisa", "hows it"],     "reply": "I am running at 100% efficiency! 💪"},
    {"keywords": ["what is ai", "ai kya", "artificial"],  "reply": "AI = Machines that think like humans! 🧠"},
    {"keywords": ["your name", "tera naam", "who are you"],"reply": "I am DecoBot, built at DecodeLabs! ⚡"},
    {"keywords": ["machine learning", "ml kya"],          "reply": "ML = AI that learns from data automatically! 📊"},
    {"keywords": ["python", "python kya"],                "reply": "Python is the #1 language for AI development! 🐍"},
    {"keywords": ["decodelabs", "decode labs"],           "reply": "DecodeLabs is an amazing AI training platform! 🚀"},
    {"keywords": ["help", "madad", "guide"],              "reply": "Ask me about AI, ML, Python or DecodeLabs! 💡"},
    {"keywords": ["bye", "goodbye", "khuda hafiz"],       "reply": "Goodbye! Keep learning AI! 👋"},
    {"keywords": ["thanks", "thank you", "shukriya"],     "reply": "You are welcome! Always here to help 😊"},
    {"keywords": ["what is chatbot", "chatbot kya"],      "reply": "Chatbot = A program that talks like a human! 💬"},
    {"keywords": ["deep learning", "dl kya"],             "reply": "Deep Learning uses neural networks like a brain! 🧬"},
]

# CONVERSATION HISTORY
history = []

# PARTIAL MATCH FUNCTION
def get_reply(user_input):
    for item in knowledge_base:
        for keyword in item["keywords"]:
            if keyword in user_input:
                return item["reply"]
    return "Hmm, I don't understand that yet. Try asking about AI or ML! 🤔"

# WELCOME SCREEN
print(Colors.CYAN + Colors.BOLD)
print("=" * 50)
print("     Welcome to DecoBot - PRO Version 🤖")
print("     Built by: DecodeLabs Intern")
print("     Type 'history' to see chat history")
print("     Type 'exit' to quit")
print("=" * 50)
print(Colors.RESET)

# MAIN LOOP
while True:

    # INPUT
    raw = input(Colors.YELLOW + "You: " + Colors.RESET)

    # SANITIZATION
    clean = raw.lower().strip()

    # EXIT
    if clean == "exit":
        print(Colors.RED + "DecoBot: Goodbye! Keep building AI! 👋" + Colors.RESET)
        break

    # HISTORY COMMAND
    if clean == "history":
        print(Colors.CYAN + "\n--- Chat History ---" + Colors.RESET)
        if len(history) == 0:
            print("No history yet!")
        else:
            for i, chat in enumerate(history):
                print(f"  {i+1}. You: {chat['user']}")
                print(f"     Bot: {chat['bot']}")
        print()
        continue

    # GET REPLY
    reply = get_reply(clean)

    # SAVE TO HISTORY
    history.append({"user": raw, "bot": reply})

    # OUTPUT
    print(Colors.GREEN + "DecoBot: " + reply + Colors.RESET)
    print()