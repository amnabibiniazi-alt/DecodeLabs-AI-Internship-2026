// ============================================
// DecodeLabs AI Internship - Project 1
// chatbot.js - Brain of DecoBot 🧠
// ============================================

// KNOWLEDGE BASE
const knowledgeBase = [
    {
        keywords: ["hello", "hi", "hey", "assalam", "salam"],
        reply: "Hello! 👋 Welcome to DecoBot! How can I help you today?"
    },
    {
        keywords: ["how are you", "kaisa", "hows it", "how r you"],
        reply: "I am running at 100% efficiency! 💪 Ready to help you learn AI!"
    },
    {
        keywords: ["what is ai", "ai kya", "artificial intelligence", "tell me about ai"],
        reply: "🧠 AI (Artificial Intelligence) means teaching machines to think like humans! It includes ML, Deep Learning, and more!"
    },
    {
        keywords: ["your name", "tera naam", "who are you", "what are you"],
        reply: "I am DecoBot! 🤖 Built by a DecodeLabs AI Intern. Nice to meet you!"
    },
    {
        keywords: ["machine learning", "ml kya", "what is ml"],
        reply: "📊 Machine Learning = AI that learns from data automatically without being explicitly programmed!"
    },
    {
        keywords: ["what is python", "python kya", "python"],
        reply: "🐍 Python is the #1 programming language for AI & Data Science! Easy to learn and very powerful!"
    },
    {
        keywords: ["deep learning", "dl kya", "what is dl"],
        reply: "🧬 Deep Learning uses Neural Networks inspired by the human brain! It powers ChatGPT and image recognition!"
    },
    {
        keywords: ["decodelabs", "decode labs", "company"],
        reply: "🚀 DecodeLabs is an amazing AI training platform that turns students into professional AI Engineers!"
    },
    {
        keywords: ["what is chatbot", "chatbot kya", "how do you work"],
        reply: "💬 I am a Rule-Based Chatbot! I match your input with my knowledge base and give replies. No ML yet — pure logic!"
    },
    {
        keywords: ["help", "madad", "guide", "what can you do"],
        reply: "💡 I can answer questions about: AI, ML, Python, Deep Learning, DecodeLabs! Just ask me anything!"
    },
    {
        keywords: ["thanks", "thank you", "shukriya", "thankyou"],
        reply: "You are welcome! 😊 Keep learning and keep building!"
    },
    {
        keywords: ["bye", "goodbye", "khuda hafiz", "alvida"],
        reply: "Goodbye! 👋 Keep building AI projects. See you soon!"
    },
    {
        keywords: ["what is neural network", "neural network"],
        reply: "🕸️ Neural Networks are computing systems inspired by the human brain — made of layers of connected nodes!"
    },
    {
        keywords: ["what is data science", "data science"],
        reply: "📈 Data Science = Extracting insights from data using statistics, ML and visualization!"
    },
    {
        keywords: ["internship", "decodelabs internship"],
        reply: "🎓 This DecodeLabs Internship will make you a professional AI Engineer step by step. Keep going!"
    },
];

// FALLBACK REPLY
const fallback = "🤔 Hmm, I don't understand that yet! Try asking about AI, ML, Python or DecodeLabs!";

// GET REPLY FUNCTION - Partial Matching
function getReply(userInput) {
    const input = userInput.toLowerCase().trim();
    for (let item of knowledgeBase) {
        for (let keyword of item.keywords) {
            if (input.includes(keyword)) {
                return item.reply;
            }
        }
    }
    return fallback;
}

// ADD MESSAGE TO CHAT
function addMessage(text, sender) {
    const chatMessages = document.getElementById('chatMessages');

    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const avatar = document.createElement('div');
    avatar.classList.add('avatar');
    avatar.textContent = sender === 'bot' ? '🤖' : '👤';

    const bubble = document.createElement('div');
    bubble.classList.add('bubble');
    bubble.textContent = text;

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(bubble);

    chatMessages.appendChild(messageDiv);

    // Auto scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// TYPING INDICATOR
function showTyping() {
    const chatMessages = document.getElementById('chatMessages');

    const typingDiv = document.createElement('div');
    typingDiv.classList.add('typing');
    typingDiv.id = 'typingIndicator';

    typingDiv.innerHTML = `
        <div class="avatar">🤖</div>
        <div class="typing-bubble">
            <span></span>
            <span></span>
            <span></span>
        </div>
    `;

    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// REMOVE TYPING INDICATOR
function hideTyping() {
    const typing = document.getElementById('typingIndicator');
    if (typing) typing.remove();
}

// SEND MESSAGE FUNCTION
function sendMessage() {
    const input = document.getElementById('userInput');
    const userText = input.value.trim();

    if (userText === '') return;

    // Show user message
    addMessage(userText, 'user');
    input.value = '';

    // Show typing indicator
    showTyping();

    // Bot reply after delay (realistic feel)
    setTimeout(() => {
        hideTyping();
        const reply = getReply(userText);
        addMessage(reply, 'bot');
    }, 1000);
}

// QUICK REPLY BUTTONS
function sendQuick(text) {
    document.getElementById('userInput').value = text;
    sendMessage();
}

// ENTER KEY SUPPORT
function handleKey(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// WELCOME MESSAGE on load
window.onload = function() {
    setTimeout(() => {
        addMessage("Hello! 👋 I am DecoBot, your AI Assistant! Ask me anything about AI, ML or Python!", 'bot');
    }, 500);
};