"""
Project 3: Tech Stack Recommender
DecodeLabs - AI Recommendation Logic (Content-Based Filtering)

Pipeline (IPO Model):
  1. Ingestion  -> take user's skills as input
  2. Scoring    -> TF-IDF vectorization + Cosine Similarity
  3. Sorting    -> rank job roles by similarity score
  4. Filtering  -> return Top-N (default 3) recommendations
"""

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class TechStackRecommender:
    def __init__(self, csv_path="raw_skills.csv"):
        # Step 1: Load dataset (job roles + their skill sets)
        self.data = pd.read_csv(csv_path)

        # Step 2: Build TF-IDF vectorizer on the "skills" column
        # This converts text skills into weighted numeric vectors
        self.vectorizer = TfidfVectorizer()
        self.item_vectors = self.vectorizer.fit_transform(self.data["skills"])

    def recommend(self, user_skills, top_n=3):
        """
        user_skills: list of strings, e.g. ["Python", "Cloud", "Automation"]
        top_n: how many recommendations to return
        """
        # --- Step 1: Ingestion ---
        # Combine user's skills into a single "document" string
        user_profile_text = " ".join(user_skills)

        # Transform user input into the SAME vector space as the items
        # (must use the already-fitted vectorizer, not a new one)
        user_vector = self.vectorizer.transform([user_profile_text])

        # --- Step 2: Scoring ---
        # Cosine similarity between user vector and every job role vector
        scores = cosine_similarity(user_vector, self.item_vectors).flatten()

        # Attach scores back to the dataframe
        results = self.data.copy()
        results["match_score"] = scores

        # --- Step 3: Sorting ---
        results = results.sort_values(by="match_score", ascending=False)

        # --- Step 4: Filtering (Top-N) ---
        top_results = results.head(top_n)

        return top_results[["job_role", "match_score"]]


def main():
    recommender = TechStackRecommender("raw_skills.csv")

    print("=== Tech Stack Recommender ===")
    print("Enter at least 3 skills, separated by commas.")
    print("Example: Python, Cloud, Automation\n")

    user_input = input("Your skills: ")
    user_skills = [s.strip() for s in user_input.split(",") if s.strip()]

    if len(user_skills) < 3:
        print("\n⚠️  Please enter at least 3 skills for accurate matching.")
        return

    recommendations = recommender.recommend(user_skills, top_n=3)

    print(f"\nBased on your skills {user_skills}, here are your Top 3 career matches:\n")
    for rank, (_, row) in enumerate(recommendations.iterrows(), start=1):
        percent = round(row["match_score"] * 100, 2)
        print(f"{rank}. {row['job_role']}  —  {percent}% match")


if __name__ == "__main__":
    main()