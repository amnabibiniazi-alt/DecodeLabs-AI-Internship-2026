"""
Project 3 Capstone: Tech Stack Recommender (Advanced / GUI Version)
DecodeLabs - AI Recommendation Logic (Content-Based Filtering)

Run with:  streamlit run app.py

Pipeline (IPO Model) - as required by the project brief:
  1. Ingestion  -> capture user skills (min 3)
  2. Scoring    -> TF-IDF vectorization + Cosine Similarity
  3. Sorting    -> rank job roles by similarity score
  4. Filtering  -> return Top-3 recommendations with matched tools/platforms
"""

import streamlit as st
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ---------------------------------------------------------
# PAGE CONFIG
# ---------------------------------------------------------
st.set_page_config(
    page_title="Tech Stack Recommender | DecodeLabs",
    page_icon="🧭",
    layout="centered"
)

# ---------------------------------------------------------
# LOAD DATA + BUILD THE RECOMMENDATION ENGINE
# ---------------------------------------------------------
@st.cache_data
def load_data():
    return pd.read_csv("raw_skills.csv")

@st.cache_resource
def build_engine(data):
    vectorizer = TfidfVectorizer()
    item_vectors = vectorizer.fit_transform(data["skills"])
    return vectorizer, item_vectors

data = load_data()
vectorizer, item_vectors = build_engine(data)

def recommend(user_skills, top_n=3):
    # --- Step 1: Ingestion ---
    user_profile_text = " ".join(user_skills)
    user_vector = vectorizer.transform([user_profile_text])

    # --- Step 2: Scoring ---
    scores = cosine_similarity(user_vector, item_vectors).flatten()

    results = data.copy()
    results["match_score"] = scores

    # --- Step 3: Sorting ---
    results = results.sort_values(by="match_score", ascending=False)

    # --- Step 4: Filtering ---
    return results.head(top_n)

# ---------------------------------------------------------
# UI - HEADER
# ---------------------------------------------------------
st.markdown(
    """
    <div style="text-align:center; padding: 10px 0 20px 0;">
        <h1 style="margin-bottom:0;">🧭 Tech Stack Recommender</h1>
        <p style="color:gray; font-size:16px;">
            Powered by TF-IDF + Cosine Similarity &nbsp;|&nbsp; DecodeLabs AI Recommendation Logic
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

st.write(
    "Enter at least **3 skills** you have or want to work with. "
    "The engine will map them to a mathematical vector space and find the "
    "career paths that align most closely — the same core logic that powers "
    "recommendation engines like Netflix and Amazon."
)

with st.expander("📂 View available skill dataset"):
    st.dataframe(data[["job_role", "skills"]], use_container_width=True)

# ---------------------------------------------------------
# UI - INPUT SECTION
# ---------------------------------------------------------
all_skills = sorted(set(" ".join(data["skills"]).split()))

col1, col2 = st.columns(2)
with col1:
    input_mode = st.radio("How do you want to enter skills?", ["Pick from list", "Type manually"])

user_skills = []

if input_mode == "Pick from list":
    user_skills = st.multiselect(
        "Select at least 3 skills:",
        options=all_skills,
        placeholder="e.g. Python, Cloud, Automation"
    )
else:
    raw_text = st.text_input("Type skills, separated by commas:", placeholder="Python, Cloud, Automation")
    user_skills = [s.strip() for s in raw_text.split(",") if s.strip()]

# ---------------------------------------------------------
# UI - RESULTS
# ---------------------------------------------------------
if st.button("🔍 Find My Tech Stack", type="primary", use_container_width=True):
    if len(user_skills) < 3:
        st.warning("⚠️ Please enter at least 3 skills for accurate matching.")
    else:
        recommendations = recommend(user_skills, top_n=3)
        st.success(f"Based on: **{', '.join(user_skills)}**")
        st.markdown("### 🏆 Your Top 3 Career Matches")

        medals = ["🥇", "🥈", "🥉"]
        for i, (_, row) in enumerate(recommendations.iterrows()):
            percent = round(row["match_score"] * 100, 1)
            with st.container(border=True):
                st.markdown(f"#### {medals[i]} {row['job_role']}")
                st.progress(min(percent / 100, 1.0), text=f"{percent}% match")
                st.caption(f"🛠️ Recommended tools & platforms: {row['tools_platforms']}")

        st.markdown("---")
        st.caption(
            "Pipeline used: Ingestion → TF-IDF Scoring → Sorting → Top-3 Filtering "
            "(Content-Based Filtering, no user history required)."
        )